import static org.junit.Assert.*;

import javax.script.ScriptException;

import org.junit.Test;

public class CalculateTest {

	@Test
	public void test() { 
		String ex ="3*4-6/2"; 
		assertEquals("9",new Calculate().calculateExpression(ex));
	}
	
	@Test()
	public void test2(){
		String ex ="3*4-6/";
		assertEquals(null,new Calculate().calculateExpression(ex));
	}
}
