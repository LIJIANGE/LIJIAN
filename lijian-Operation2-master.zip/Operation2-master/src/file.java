import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;

public class file {
	public static void MakeFile(ArrayList<String> ex){
		try{ 
            File file = new File("../results.txt");
            if (file.exists()) {   
                file.delete(); 
            }
            if(file.createNewFile()){
                FileOutputStream txtfile = new FileOutputStream(file);
                PrintStream ps = new PrintStream(txtfile);
                for (int i = 0; i < ex.size(); i++) {
					ps.println(ex.get(i));
				}
                txtfile.close();
                ps.close();
                System.out.println("�ļ������ɹ�");
            }

        }
        catch(IOException io) {
        	
            io.printStackTrace();
        }
	}
}

