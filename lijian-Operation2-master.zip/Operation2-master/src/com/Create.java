package com;

import java.util.ArrayList;
import java.util.Random;


import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class Create {
	public static ArrayList<String> createExpression(int num,int scope_Lower,int scope_Upper,int sumOfOperation,boolean mul_Div,boolean bracketExist){
		ArrayList<String> expression = new ArrayList<String>();
		char[] operator= new char[]{'+','-','*','/'};
		Random random = new Random();
		for (int i = 0; i < num; i++) {  
			String ex = new String(); 
			int result=0;
			char[] operatorCreate = new char[sumOfOperation];
			int[] number = new int[sumOfOperation+1];//������Ҫ���������һ
			for (int j = 0; j <= sumOfOperation; j++) {
				number[j] = random.nextInt(scope_Upper-scope_Lower+1)+scope_Lower;
			}
			result=number[0];
			operatorCreate[0]=operator[random.nextInt(4)];
			for (int j = 1; j < sumOfOperation; j++) {
				int op=0;
				if(mul_Div)
					op = random.nextInt(4);//�Ƿ��г˳���
				else
					op = random.nextInt(2);
				operatorCreate[j]=operator[op];
				while(operatorCreate[j]==operatorCreate[j-1]) {
					if(mul_Div)
						op = random.nextInt(4);
					else
						op = random.nextInt(2);
					operatorCreate[j]=operator[op];
				}
			}
			ex+=String.valueOf(number[0]);
			for(int j=0;j<=sumOfOperation-1;j++){
				//���м������д������ų�һЩ�����������
				if(operatorCreate[j]=='+') {
					while(result+number[j+1]>scope_Upper)
						number[j+1]=random.nextInt(scope_Upper);
					result+=number[j+1];
				}
				if(operatorCreate[j]=='-') {
					result-=number[j+1];
				}
				if(operatorCreate[j]=='*') {
					while(result*number[j+1]>scope_Upper)
						number[j+1]=random.nextInt(scope_Upper);
					result*=number[j+1];
				}
				if(operatorCreate[j]=='/') {
					while(result%number[j+1]!=0)
						number[j+1]=random.nextInt(scope_Upper)+1;
					result/=number[j+1];
				}
				if(j>0&&bracketExist&&priority(operatorCreate[j-1])<priority(operatorCreate[j])){
					ex="("+ex+")"+operatorCreate[j]+String.valueOf(number[j+1]);
				}
				else{
					ex+=operatorCreate[j]+String.valueOf(number[j+1]);
				}
			}
			if(Math.abs(result)>scope_Upper||Math.abs(result)<scope_Lower){
				i--;
				continue;
			}
			if(expression.contains(ex)) {
				i--;
				continue;
			}
			expression.add(ex);
		}
		return expression; 
	}
	private static int priority(char c)
	{
		if(c=='+'||c=='-')
			return 0;
		else
			return 1;
	}
}
