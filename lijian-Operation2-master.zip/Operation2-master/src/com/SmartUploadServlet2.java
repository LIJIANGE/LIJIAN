package com;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspsmart.upload.SmartUpload;
import com.jspsmart.upload.SmartUploadException;

@WebServlet("/SmartUploadServlet2")
public class SmartUploadServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public SmartUploadServlet2() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SmartUpload smart = new SmartUpload();//ʵ����SmartUpload����
		smart.initialize(this.getServletConfig(),request,response);//��ʼ���ϴ�����
		try {
			smart.upload();//�ϴ�׼��
		} catch (SmartUploadException e) {
			e.printStackTrace();
		}
		com.jspsmart.upload.File myFile = smart.getFiles().getFile(0);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String fileName = sdf.format(new Date())+"."+myFile.getFileExt();
		String filePath = this.getServletContext().getRealPath("/")+"upload"+java.io.File.separator+fileName;
		try {
			myFile.saveAs(filePath);
			File file = new File(filePath);
			try {
				InputStreamReader read = new InputStreamReader(new FileInputStream(file), "UTF-8");
				BufferedReader br = new BufferedReader(read);
				String ex = null;
				List<String> expression = new ArrayList<String>();
				List<String> answerList = new ArrayList<String>();
				while ((ex = br.readLine()) != null) {
					//Answer answer = new Answer();
					expression.add(ex);
					//answerList.add(answer.solution(s));
				}
				br.close();
				request.setAttribute("expression", expression);
				//request.setAttribute("answerList", answerList);
				request.getRequestDispatcher("/UserCalEnglish.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SmartUploadException e) {
			e.printStackTrace();
		}
	}

}
