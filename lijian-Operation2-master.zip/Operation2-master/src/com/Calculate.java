package com;
import java.util.Stack;
import java.util.regex.Pattern;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
 
public class Calculate {  
	static ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
	public static String calculateExpression(String ex){
			try {  
				return String.valueOf(engine.eval(ex));
			} catch (ScriptException e) { 
				e.printStackTrace();
				return null; 
			} 
	}
}