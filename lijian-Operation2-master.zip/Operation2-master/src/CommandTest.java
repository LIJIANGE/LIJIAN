import org.junit.Test;

import static org.junit.Assert.assertEquals;

class CommandTest {

	//����������
	@Test
	public void TestMain() {
		String args1[]= {"-n","10","-m","10","100","-o","6","-c","-b"};
		String args2[]= {"-N","10","-M","10","100","-O","6","-C","-B"};
		String args3[]= {"-z"};
		String args4[]= {"-o","-t"};
		String args5[]= {"-o","-1"};
		new Command();
		Command.main(args1);
		Command.main(args2);
		Command.main(args3);
		Command.main(args4);
		Command.main(args5);
	}
	//��������Ĳ����Ƿ�Ϸ�
	@Test()
	public void testParameter1Error1(){
		String ex ="-n";
		assertEquals(true,new Command().parameter1Error(ex));
	}
	@Test() 
	public void testParameter1Error2(){
		String ex ="-z";
		assertEquals(false,new Command().parameter1Error(ex));
	}
	
	//��������Ĳ���n�Ƿ�Ϸ�
	@Test
	public void testScopeOfSumError1(){
		int num=-1;
		assertEquals(false, new Command().scopeOfSumError(num));
	}
	@Test
	public void testScopeOfSumError2(){
		int num=10;
		assertEquals(true, new Command().scopeOfSumError(num));
	}
	
	
	//��������Ĳ���m�Ƿ�Ϸ�
	@Test
	public void testScopeOfArgsMError1(){
		int scope_Lower=-1;
		int scope_Upper=1001;
		assertEquals(1, new Command().ScopeOfArgsMError(scope_Lower, scope_Upper));
	}
	@Test
	public void testScopeOfArgsMError2(){
		int scope_Lower=80;
		int scope_Upper=50;
		assertEquals(2, new Command().ScopeOfArgsMError(scope_Lower, scope_Upper));
	}
	@Test
	public void testScopeOfArgsMError3(){
		int scope_Lower=10;
		int scope_Upper=90;
		assertEquals(3, new Command().ScopeOfArgsMError(scope_Lower, scope_Upper));
	}
	
	//��������Ĳ���o�Ƿ�Ϸ�
	@Test 
	public void testSumOfOperationError1(){
		int sumOfOperation = 20;
		assertEquals(false, new Command().sumOfOperationError(sumOfOperation));
	} 
	@Test
	public void testSumOfOperationError2(){
		int sumOfOperation = 4;
		assertEquals(true, new Command().sumOfOperationError(sumOfOperation));
	}
}
